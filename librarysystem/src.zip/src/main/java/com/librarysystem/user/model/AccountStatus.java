package com.librarysystem.user.model;

public enum AccountStatus {
    PENDING,
    APPROVED,
    REJECTED
}
