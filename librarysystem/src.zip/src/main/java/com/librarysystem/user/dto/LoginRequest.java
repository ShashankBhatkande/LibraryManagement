package com.librarysystem.user.dto;

public record LoginRequest(String email, String password) {
}
