package com.librarysystem.borrow.dto;

public record ReturnBookRequest(Long id) {

}
