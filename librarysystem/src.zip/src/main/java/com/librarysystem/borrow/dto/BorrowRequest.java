package com.librarysystem.borrow.dto;

public record BorrowRequest(String username, Long bookId) {

}
