package com.librarysystem.borrow.model;

public enum BorrowStatus {
    BORROWED,
    RETURNED,
    OVERDUE,
    RETURNCONFIRMED
}
